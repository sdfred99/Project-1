#include "Lexer.h"

int main(int argc, char** argv) {

    Lexer* lexer = new Lexer();

    // TODO

    delete lexer;

    return 0;
}